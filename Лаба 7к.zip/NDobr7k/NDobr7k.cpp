﻿#include <iostream>
#include "Money.h"
#include "Vector.h"

using namespace std;

int main()
{
  setlocale(LC_ALL, "rus");
  
  int n;
  cout << "Количество элементов в int-векторе А: "; cin >> n;

  Vector<int> intVecA(n);
  cout << "Введите вектор: ";
  for (int i = 0; i < intVecA.Size(); i++)
    cin >> intVecA[i];

  cout << "Количество элементов в int-векторе B: "; cin >> n;
  Vector<int> intVecB;
  cout << "Введите вектор: ";
  for (int i = 0; i < n; i++)
  {
    int temp; cin >> temp;
    intVecB.Push(temp);
  }

  {
    cout << "A + B = ";
    Vector<int> temp = intVecA;
    temp + intVecB;
    cout << temp << endl;
  }
  {
    cout << "B + A = ";
    Vector<int> temp = intVecB;
    temp + intVecA;
    cout << temp << endl;
  }

  cout << "Количество элементов в money-векторе: "; cin >> n;
  Vector<Money> moneyVec(n);
  cout << "Введите элементы вектора: ";
  for (int i = 0; i < moneyVec.Size(); i++)
  {
    cin >> moneyVec[i];
  }

  cout << "Счета: " << moneyVec << endl;
}
