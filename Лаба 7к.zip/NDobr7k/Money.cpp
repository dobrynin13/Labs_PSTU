#include "Money.h"
#include <iostream>

Money::Money(long r, int k)
{
  rub = r + (k / 100);
  kop = k % 100;
}

Money::Money(const Money& ref)
{
  rub = ref.rub;
  kop = ref.kop;
}

void Money::SetRub(long r) { rub = r; }

void Money::SetKop(int k) { kop = k; }

long Money::GetRub() { return rub; }

int Money::GetKop() { return kop; }

void Money::operator+(double add)
{
  int temp = add * 100;
  kop += temp % 100;
  rub += (temp / 100 + kop / 100);
}

bool Money::operator>(const Money& ref) { return (rub > ref.rub && kop > ref.kop); }

bool Money::operator==(const Money& ref) { return (rub == ref.rub && kop == ref.kop); }

bool Money::operator<(const Money& ref) { return (rub < ref.rub&& kop < ref.kop); }

Money& Money::operator=(const Money& ref)
{
  this->rub = ref.rub;
  this->kop = ref.kop;
  return *this;
}

std::ostream& operator<<(std::ostream& out, const Money& ref)
{
  out << ref.rub << ',';
  if (ref.kop < 10) out << '0';
  out << ref.kop;

  return out;
}

std::istream& operator>>(std::istream& in, Money& ref)
{
  float temp;
  in >> temp;
  temp *= 100;
  ref.rub = temp / 100;
  ref.kop = static_cast<int>(temp) % 100;
  return in;
}